0808 - hetero, corresponding to experimentSet1
0908 - probably homo