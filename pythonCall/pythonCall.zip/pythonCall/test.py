
file=open('new.txt','w')
file.write("hey")